let tasks = [];
let viewMode = "list"; 
let toggleViewButton;
let inputTitle, taskFilterSelect, selectCategory, inputTime, inputDate, addButton;
let message = "";
let messageTimer = 0;
let sortSelect; 

function setup() {
  createCanvas(700, 500);
  textAlign(LEFT, CENTER);
  textSize(18);
  
  // --- Inputs ---
  inputTitle = createInput();
  inputTitle.position(20, 20);
  inputTitle.size(200);
  inputTitle.attribute('placeholder', 'Τίτλος εργασίας');
  
  selectCategory = createSelect();
  selectCategory.position(230, 20);
  selectCategory.option('Πανεπιστήμιο');
  selectCategory.option('Δουλειά');
  selectCategory.option('Χόμπι');
  selectCategory.option('Ελεύθερος χρόνος');
  
  inputDate = createInput();
  inputDate.position(370, 20);
  inputDate.size(100);
  inputDate.attribute('placeholder', 'Ημ/νία');
  inputDate.attribute('type', 'date');

  inputTime = createInput();
  inputTime.position(480, 20);
  inputTime.size(80);
  inputTime.attribute('placeholder', 'Ώρα');
  inputTime.attribute('type', 'time');

  addButton = createButton('Προσθήκη');
  addButton.position(570, 20);
  addButton.mousePressed(addTask);
  
  // --- Filter & Sort ---
  taskFilterSelect = createSelect();
  taskFilterSelect.position(20, 60);
  taskFilterSelect.option('Όλες');
  taskFilterSelect.option('Ολοκληρωμένες');
  taskFilterSelect.option('Μη ολοκληρωμένες');
  taskFilterSelect.option('Πανεπιστήμιο');
  taskFilterSelect.option('Δουλειά');
  taskFilterSelect.option('Χόμπι');
  taskFilterSelect.option('Ελεύθερος χρόνος');
  taskFilterSelect.changed(redraw);

  sortSelect = createSelect();
  sortSelect.position(200, 60);
  sortSelect.option('Ημερομηνία ↑');
  sortSelect.option('Ημερομηνία ↓');
  sortSelect.option('Αλφαβητικά');
  sortSelect.changed(redraw);
  
  toggleViewButton = createButton("Προβολή: Ημερολόγιο");
  toggleViewButton.position(400, 60);
  toggleViewButton.mousePressed(() => {
    viewMode = (viewMode === "list") ? "calendar" : "list";
    toggleViewButton.html("Προβολή: " + (viewMode === "list" ? "Ημερολόγιο" : "Λίστα"));
    redraw();
  });

  // --- Restore Saved Tasks ---
  let saved = localStorage.getItem("myTasks");
  if (saved) {
    let parsed = JSON.parse(saved);
    for (let item of parsed) {
      recreateTask(item);
    }
  }

  // --- Style UI ---
  styleButtons();
  
  noLoop();
}

function clearTaskButtons() {
  for (let t of tasks) {
    t.completeButton.hide();
    t.deleteButton.hide();
    if (t.notesButton) t.notesButton.hide();
    if (t.notesInput) t.notesInput.hide();
  }
}


function draw() {
  background(230);

  clearTaskButtons();
  
 let filteredTasks = tasks.filter(t => {
    let filterValue = taskFilterSelect.value();
    if (filterValue === 'Όλες') return true;
    if (filterValue === 'Ολοκληρωμένες') return t.completed;
    if (filterValue === 'Μη ολοκληρωμένες') return !t.completed;
    return t.category === filterValue;
  });

  let sort = sortSelect.value();
  filteredTasks.sort((a, b) => {
    if (sort === 'Ημερομηνία ↑') return taskDateTime(a) - taskDateTime(b);
    if (sort === 'Ημερομηνία ↓') return taskDateTime(b) - taskDateTime(a);
    if (sort === 'Αλφαβητικά') return a.title.localeCompare(b.title);
  });

  // --- Draw ---
  if (viewMode === "list") {
    drawListView(filteredTasks);
  } else {
    drawCalendarView(filteredTasks);
  }

  // --- Messages ---
  if (messageTimer > 0) {
    fill(0, 150, 0);
    textAlign(CENTER, CENTER);
    textSize(20);
    text(message, width / 2, height - 40);
    textAlign(LEFT, CENTER);
    messageTimer--;
  }
}

//
// ---------- Helpers ----------
//

function drawListView(filteredTasks) {
  let y = 110; // starting y

  for (let t of filteredTasks) {
    let emoji = "";
    switch (t.category) {
      case 'Πανεπιστήμιο': emoji = "📚"; break;
      case 'Δουλειά': emoji = "💼"; break;
      case 'Χόμπι': emoji = "🎨"; break;
      case 'Ελεύθερος χρόνος': emoji = "🎉"; break;
    }
    
    // Task background
    fill(categoryColor(t.category));
    rect(20, y - 15, 540, 30, 8); 

    // Task text
    if (t.completed) {
      fill(180);
      textStyle(ITALIC);
      text(`${emoji} ${t.title} [${t.category}] - ${t.time}`, 30, y);
      line(30, y, 30 + textWidth(`${emoji} ${t.title} [${t.category}] - ${t.time}`), y);
    } else {
      fill(30);
      textStyle(NORMAL);
      text(`${emoji} ${t.title} [${t.category}] - ${t.time}`, 30, y);
    }

    // Buttons
  t.completeButton.show();
  t.completeButton.position(460, y - 15);
  t.completeButton.size(105, 20);

  t.deleteButton.show();
  t.deleteButton.position(570, y - 15);
  t.deleteButton.size(30, 20);

  if (t.notesButton) {
    t.notesButton.show();
    t.notesButton.position(610, y - 15);
    t.notesButton.size(90, 20);
  }

  if (t.notesInput) {
    t.notesInput.show();
    t.notesInput.position(30, y + 10);
  }

  y += 40;
}
}

function drawCalendarView(tasks) {
  const days = ['Κυρ', 'Δευ', 'Τρι', 'Τετ', 'Πεμ', 'Παρ', 'Σαβ'];
  const colWidth = width / 7;
  const rowHeight = 80;

  for (let i = 0; i < 7; i++) {
    fill(200);
    rect(i * colWidth, 110, colWidth, rowHeight);
    fill(0);
    textAlign(CENTER, CENTER);
    textSize(16);
    text(days[i], i * colWidth + colWidth / 2, 110 + rowHeight / 2);
  }

  let dayHeights = Array(7).fill(110 + rowHeight + 10);

  for (let t of tasks) {
    let date = new Date(`${t.date}T${t.time}`);
    if (isNaN(date)) continue;

    let day = date.getDay();
    let x = day * colWidth + 10;
    let y = dayHeights[day];

    fill(categoryColor(t.category));
    rect(x - 5, y - 5, 220, 45, 10);

    fill(t.completed ? 150 : 20);
    textAlign(LEFT, TOP);
    textSize(14);
    text(`${t.title} (${t.category})`, x, y);

    t.completeButton.position(x, y + 20);
    t.completeButton.size(100, 20);
    t.deleteButton.position(x + 105, y + 20);
    t.deleteButton.size(30, 20);

    dayHeights[day] += 50;
  }
}

function addTask() {
  let title = inputTitle.value().trim();
  let category = selectCategory.value();
  let date = inputDate.value().trim();
  let time = inputTime.value().trim();
  
  if (title === "") {
    message = "Πρέπει να γράψεις τίτλο!";
    messageTimer = 120;
    return;
  }

  let task = createTaskObject({title, category, date, time, completed: false, notes: ""});
  tasks.push(task);

  // reset inputs
  inputTitle.value('');
  inputTime.value('');
  inputDate.value('');
  
  saveTasks();
  
  redraw();
}

function recreateTask(data) {
  let task = createTaskObject(data);
  tasks.push(task);
}

function createTaskObject(data) {
  let task = {
    title: data.title,
    category: data.category,
    date: data.date,
    time: data.time,
    completed: data.completed,
    notes: data.notes || "",
    notesInput: null
  };

  // Complete Button
  task.completeButton = createButton(task.completed ? '✔️' : 'Ολοκληρώθηκε');
  task.completeButton.mousePressed(() => {
    task.completed = !task.completed;
    task.completeButton.html(task.completed ? '✔️' : 'Ολοκληρώθηκε');
    saveTasks(); 
    redraw();
  });

  // Delete Button
  task.deleteButton = createButton('🗑️');
  task.deleteButton.mousePressed(() => {
    task.completeButton.remove();
    task.deleteButton.remove();
    if (task.notesButton) task.notesButton.remove();
    if (task.notesInput) task.notesInput.remove();
    tasks = tasks.filter(t => t !== task);
    saveTasks(); 
    redraw();
  });

  // Notes Button
  task.notesButton = createButton('✏️ Σημειώσεις');
  task.notesButton.mousePressed(() => {
    if (!task.notesInput) {
      task.notesInput = createInput(task.notes);
      task.notesInput.size(300);
      task.notesInput.position(task.completeButton.x + 150, task.completeButton.y);
      task.notesInput.input(() => {
        task.notes = task.notesInput.value();
        saveTasks();
      });
    } else {
      task.notesInput.remove();
      task.notesInput = null;
    }
  });

  // Style buttons
  styleTaskButtons(task);

  return task;
}

function saveTasks() {
  let data = tasks.map(t => ({
    title: t.title,
    category: t.category,
    date: t.date,
    time: t.time,
    completed: t.completed,
    notes: t.notes
  }));
  localStorage.setItem("myTasks", JSON.stringify(data));
}

function taskDateTime(task) {
  return new Date(`${task.date}T${task.time}`);
}

// Category colors
function categoryColor(category) {
  switch (category) {
    case 'Πανεπιστήμιο': return color(135, 206, 250); // Light blue
    case 'Δουλειά': return color(255, 182, 193);      // Light pink
    case 'Χόμπι': return color(152, 251, 152);        // Pale green
    case 'Ελεύθερος χρόνος': return color(255, 218, 185); // Peach
    default: return color(240);
  }
}

//
// ---------- Styling ----------
//

function styleButtons() {
  // Add button
  addButton.style('background-color', '#4CAF50');
  addButton.style('color', 'white');
  addButton.style('border', 'none');
  addButton.style('padding', '5px 15px');
  addButton.style('border-radius', '4px');
  
  // Toggle button
  toggleViewButton.style('background-color', '#2196F3');
  toggleViewButton.style('color', 'white');
  toggleViewButton.style('border', 'none');
  toggleViewButton.style('padding', '5px 15px');
  toggleViewButton.style('border-radius', '4px');
  
  // Selects
  const selectStyle = 'background-color: #f0f0f0; padding: 5px; border-radius: 4px;';
  selectCategory.style(selectStyle);
  taskFilterSelect.style(selectStyle);
  sortSelect.style(selectStyle);
}

function styleTaskButtons(task) {
  task.completeButton.style('background-color', '#4CAF50');
  task.completeButton.style('color', 'white');
  task.completeButton.style('border', 'none');
  task.completeButton.style('border-radius', '4px');
  
  task.deleteButton.style('background-color', '#f44336');
  task.deleteButton.style('color', 'white');
  task.deleteButton.style('border', 'none');
  task.deleteButton.style('border-radius', '4px');
  
  task.notesButton.style('background-color', '#ff9800');
  task.notesButton.style('color', 'white');
  task.notesButton.style('border', 'none');
  task.notesButton.style('border-radius', '4px');
}
